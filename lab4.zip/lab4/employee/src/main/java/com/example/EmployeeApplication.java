package com.example;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.web.client.RestClient;

@SpringBootApplication
public class EmployeeApplication {

    public static void main(String[] args) {
        SpringApplication.run(EmployeeApplication.class, args);
    }

    @Bean
    public RestClient createRestClient() {
        return RestClient.create();
    }

//    @Bean
//    public CommandLineRunner initData(CompanyService companyService, EmployeeService employeeService) {
////        return args -> {
////            extracted(companyService);
////
////            companyService.findAll().forEach(foundCompany -> {
////                EmployeeCreateDto employeeCreateDto = new EmployeeCreateDto(foundCompany.getName() + " employee", "employee title", (double) System.currentTimeMillis(), foundCompany.getId());
////                employeeService.create(employeeCreateDto);
////            });
////        };
//    }
//
//    @Transactional
//    public void extracted(CompanyService companyService) {
//        CompanyCreateDto c1 = new CompanyCreateDto("Acme Inc", "Manufacturing");
//        CompanyCreateDto c2 = new CompanyCreateDto("Globex", "Finance");
//
//        companyService.create(c1);
//        companyService.create(c2);
//    }
}
