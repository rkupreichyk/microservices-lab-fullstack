package com.example;

import com.example.collection.CompanyCollectionDto;
import com.example.create.CompanyCreateDto;
import com.example.create.EmployeeCreateDto;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;

import com.example.service.CompanyService;
import com.example.service.EmployeeService;
import com.example.model.Company;
import com.example.model.Employee;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@SpringBootApplication
public class Lab2Application {

    public static void main(String[] args) {
        SpringApplication.run(Lab2Application.class, args);
    }

//    @Bean
//    public CommandLineRunner initData(CompanyService companyService, EmployeeService employeeService) {
////        return args -> {
////            extracted(companyService);
////
////            companyService.findAll().forEach(foundCompany -> {
////                EmployeeCreateDto employeeCreateDto = new EmployeeCreateDto(foundCompany.getName() + " employee", "employee title", (double) System.currentTimeMillis(), foundCompany.getId());
////                employeeService.create(employeeCreateDto);
////            });
////        };
//    }
//
//    @Transactional
//    public void extracted(CompanyService companyService) {
//        CompanyCreateDto c1 = new CompanyCreateDto("Acme Inc", "Manufacturing");
//        CompanyCreateDto c2 = new CompanyCreateDto("Globex", "Finance");
//
//        companyService.create(c1);
//        companyService.create(c2);
//    }
}
