import {Component, OnInit, inject, ChangeDetectorRef} from '@angular/core';
import { ActivatedRoute, RouterLink } from '@angular/router';
import { DataService } from './data.service';
import { Company, Employee } from './data.model';
import {CommonModule} from '@angular/common'; // Убедитесь, что интерфейс Employee создан

@Component({
  standalone: true,
  imports: [CommonModule, RouterLink],
  templateUrl: './company-details.component.html'
})
export class CompanyDetailsComponent implements OnInit {
  private route = inject(ActivatedRoute);
  private dataService = inject(DataService);
  private cdr = inject(ChangeDetectorRef);

  companyId: string = '';
  company: Company | null = null;
  employees: Employee[] = [];

  ngOnInit() {
    this.companyId = this.route.snapshot.paramMap.get('id') || '';

    if (this.companyId) {
      this.loadData();
    }

    this.dataService.getEmployeesByCompany(this.companyId).subscribe({
      next: (data) => {
        this.employees = data;
        console.log('pracownicy zapissane do zmiennej:', this.employees);
        this.cdr.detectChanges();
      },
      error: (err) => console.error(err)
    });
  }

  loadData() {
    this.dataService.getCompanyById(this.companyId).subscribe(data => this.company = data);

    this.dataService.getEmployeesByCompany(this.companyId).subscribe(data => this.employees = data);
  }

  onDeleteEmployee(employeeId: string) {
    if (confirm('Chczesz usunąć pracownika?')) {
      this.dataService.deleteEmployee(employeeId).subscribe({
        next: () => {
          this.employees = this.employees.filter(e => e.id !== employeeId);
        }
      });
    }
  }
}
