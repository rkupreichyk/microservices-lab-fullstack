package com.example.read;

import com.example.model.Company;

import java.io.Serializable;
import java.util.UUID;

public class CompanyReadDto implements Serializable {
    private UUID id;
    private String name;
    private String industry;
    private int employeeCount;

    public CompanyReadDto() {}

    public CompanyReadDto(UUID id, String name, String industry, int employeeCount) {
        this.id = id;
        this.name = name;
        this.industry = industry;
        this.employeeCount = employeeCount;
    }

    public static CompanyReadDto from(Company c) {
        int count = c.getEmployees() == null ? 0 : c.getEmployees().size();
        return new CompanyReadDto(c.getId(), c.getName(), c.getIndustry(), count);
    }

    public UUID getId() { return id; }
    public String getName() { return name; }
    public String getIndustry() { return industry; }
    public int getEmployeeCount() { return employeeCount; }
}
