package com.example.lab1;

import com.example.lab1.model.Company;
import com.example.lab1.model.Employee;
import com.example.lab1.model.EmployeeDto;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import java.io.*;
import java.util.*;
import java.util.concurrent.ForkJoinPool;
import java.util.stream.Collectors;

@SpringBootApplication
public class Main implements CommandLineRunner {

    private static final String SERIAL_FILE = "companies.ser";

    public static void main(String[] args) {
        SpringApplication.run(Main.class, args);
    }

    @Override
    public void run(String... args) throws Exception {
        List<Company> companies = createSampleData();

        System.out.println("--- lista firm i pracowników ---");
        companies.forEach(c -> {
            System.out.println(c);
            c.getEmployees().forEach(e -> System.out.println("  " + e));
        });

        Set<Employee> allEmployees = companies.stream()
                .flatMap(c -> c.getEmployees().stream())
                .collect(Collectors.toCollection(LinkedHashSet::new));

        System.out.println("\n--- lista pracowników (Set) ---");
        allEmployees.forEach(System.out::println);

        System.out.println("\n--- Sortowanie według: pensja >= 60000, Sortowanie według imie ---");
        allEmployees.stream()
                .filter(e -> e.getSalary() >= 60000)
                .sorted(Comparator.comparing(Employee::getName))
                .forEach(System.out::println);

        List<EmployeeDto> dtoList = allEmployees.stream()
                .map(EmployeeDto::from)
                .sorted()
                .collect(Collectors.toList());

        System.out.println("\n--- DTO sortowana lista ---");
        dtoList.forEach(System.out::println);

        System.out.println("\n--- Serializacja w plik oraz odczyt ---");
        serializeCompanies(companies, SERIAL_FILE);
        List<Company> readBack = deserializeCompanies(SERIAL_FILE);
        readBack.forEach(c -> {
            System.out.println(c);
            c.getEmployees().forEach(e -> System.out.println("  " + e));
        });

        System.out.println("\n--- Przetwarzanie rozproszone z ForkJoinPool ---");
        ForkJoinPool pool = new ForkJoinPool(4);
        try {
            pool.submit(() -> companies.parallelStream().forEach(company -> {
                System.out.println("[Thread: " + Thread.currentThread().getName() + "] Firma: " + company.getName());
                company.getEmployees().forEach(e -> {
                    try { Thread.sleep(200); } catch (InterruptedException ex) { Thread.currentThread().interrupt(); }
                    System.out.println("[Thread: " + Thread.currentThread().getName() + "]   Pracownik: " + e.getName());
                });
            })).get();
        } finally {
            pool.shutdown();
        }

    }

    private static List<Company> createSampleData() {
        Company techCorp = new Company.Builder()
                .name("TechCorp")
                .industry("IT")
                .build();

        Company financePlus = new Company.Builder()
                .name("FinancePlus")
                .industry("Finansowe usługi")
                .build();

        Employee john = new Employee.Builder()
                .name("Raman Kupreichyk")
                .position("Programista")
                .salary(80000)
                .company(techCorp)
                .build();

        Employee anna = new Employee.Builder()
                .name("pracownik2")
                .position("tester")
                .salary(55000)
                .company(techCorp)
                .build();

        Employee peter = new Employee.Builder()
                .name("pracownik3")
                .position("Analityk")
                .salary(70000)
                .company(financePlus)
                .build();

        Employee maria = new Employee.Builder()
                .name("pracownik4")
                .position("Księgowy")
                .salary(60000)
                .company(financePlus)
                .build();

        techCorp.getEmployees().addAll(Arrays.asList(john, anna));
        financePlus.getEmployees().addAll(Arrays.asList(peter, maria));

        return Arrays.asList(techCorp, financePlus);
    }

    private static void serializeCompanies(List<Company> companies, String filename) {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(filename))) {
            oos.writeObject(companies);
            System.out.println("Dane są serializowane w plik " + filename);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @SuppressWarnings("unchecked")
    private static List<Company> deserializeCompanies(String filename) {
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(filename))) {
            Object obj = ois.readObject();
            if (obj instanceof List) {
                return (List<Company>) obj;
            }
        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
        }
        return Collections.emptyList();
    }
}