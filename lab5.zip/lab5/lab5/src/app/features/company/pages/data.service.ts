import { Injectable, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Company } from './data.model';
import { Employee } from './data.model';
import {Observable} from 'rxjs';

@Injectable({ providedIn: 'root' })
export class DataService {
  private http = inject(HttpClient); // Инъекция HttpClient
  private apiUrl = '/api/companies'; // Адрес шлюза

  getCompanies() {
    return this.http.get<Company[]>(this.apiUrl);
  }

  deleteCompany(id: string): Observable<void> {
    // Используем URL и метод GET, как вы указали
    return this.http.delete<void>(`http://localhost:9000/api/companies/${id}`);
  }

  addCompany(company: { name: string, industry: string }): Observable<Company> {
    return this.http.post<Company>('http://localhost:9000/api/companies', company);
  }

  getCompanyById(id: string): Observable<Company> {
    return this.http.get<Company>(`http://localhost:9000/api/companies/${id}`);
  }

  updateCompany(id: string, company: { name: string, industry: string }): Observable<void> {
    return this.http.put<void>(`http://localhost:9000/api/companies/${id}`, company);
  }

  getEmployeesByCompany(companyId: string): Observable<Employee[]> {
    return this.http.get<Employee[]>(`http://localhost:9000/api/employees/by-company/${companyId}`);
  }

  deleteEmployee(employeeId: string): Observable<void> {
    return this.http.delete<void>(`http://localhost:9000/api/employees/${employeeId}`);
  }

  addEmployee(employee: { name: string, position: string, companyId: string }): Observable<Employee> {
    // Запрос к микросервису сотрудников через Gateway
    return this.http.post<Employee>('http://localhost:9000/api/employees', employee);
  }

  getEmployeeById(id: string): Observable<Employee> {
    return this.http.get<Employee>(`http://localhost:9000/api/employees/${id}`);
  }

  updateEmployee(id: string, employee: Partial<Employee>): Observable<void> {
    return this.http.put<void>(`http://localhost:9000/api/employees/${id}`, employee);
  }
}
