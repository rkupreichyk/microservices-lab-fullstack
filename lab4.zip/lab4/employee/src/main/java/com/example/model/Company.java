package com.example.model;

import jakarta.persistence.*;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

//@Entity
//@Table(name = "companies")
public class Company implements Serializable {

    @Id
    private UUID id = UUID.randomUUID();

    @Column(nullable = false)
    private String name;

    private String industry;

    private List<Employee> employees = new ArrayList<>();

    public Company() {}

    public Company(String name, String industry) {
        this.name = name;
        this.industry = industry;
    }

    public UUID getId() { return id; }
    public String getName() { return name; }
    public String getIndustry() { return industry; }
    public List<Employee> getEmployees() { return employees; }

    @Override
    public String toString() {
        return "Company{" + "id=" + id + ", name='" + name + '\'' + ", industry='" + industry + '\'' + '}';
    }

    public void setId(UUID id) {
        this.id = id;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setIndustry(String industry) {
        this.industry = industry;
    }

    public void setEmployees(List<Employee> employees) {
        this.employees = employees;
    }


}
