package com.example.create;

import java.io.Serializable;
import java.util.UUID;

public class EmployeeCreateDto implements Serializable {
    private String name;
    private String position;
    private double salary;
    private UUID companyId; // устанавливается клиентом как ссылка на ресурс компании

    public EmployeeCreateDto() {}

    public EmployeeCreateDto(String name, String position, double salary, UUID companyId) {
        this.name = name;
        this.position = position;
        this.salary = salary;
        this.companyId = companyId;
    }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getPosition() { return position; }
    public void setPosition(String position) { this.position = position; }

    public double getSalary() { return salary; }
    public void setSalary(double salary) { this.salary = salary; }

    public UUID getCompanyId() { return companyId; }
    public void setCompanyId(UUID companyId) { this.companyId = companyId; }
}
