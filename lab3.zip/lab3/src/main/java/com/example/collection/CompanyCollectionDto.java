package com.example.collection;

import java.io.Serializable;
import java.util.UUID;

public class CompanyCollectionDto implements Serializable {
    private UUID id;
    private String name;

    public CompanyCollectionDto() {}

    public CompanyCollectionDto(UUID id, String name) {
        this.id = id;
        this.name = name;
    }

    public UUID getId() { return id; }
    public String getName() { return name; }
}
