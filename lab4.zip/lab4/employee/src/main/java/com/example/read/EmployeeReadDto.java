package com.example.read;

import com.example.model.Employee;

import java.io.Serializable;
import java.util.UUID;

public class EmployeeReadDto implements Serializable {
    private UUID id;
    private String name;
    private String position;
    private double salary;
    private UUID companyId;

    public EmployeeReadDto() {}

    public EmployeeReadDto(UUID id, String name, String position, double salary, UUID companyId) {
        this.id = id;
        this.name = name;
        this.position = position;
        this.salary = salary;
        this.companyId = companyId;
    }

    public static EmployeeReadDto from(Employee e) {
        return new EmployeeReadDto(e.getId(), e.getName(), e.getPosition(), e.getSalary(), e.getCompanyId());
    }

    public UUID getId() { return id; }
    public String getName() { return name; }
    public String getPosition() { return position; }
    public double getSalary() { return salary; }
    public UUID getCompanyId() { return companyId; }
}
