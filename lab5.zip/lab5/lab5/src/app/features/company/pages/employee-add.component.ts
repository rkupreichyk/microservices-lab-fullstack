import { Component, OnInit, inject } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { DataService } from './data.service';

@Component({
  standalone: true,
  imports: [FormsModule],
  template: `
    <h2>Dodać pracownika</h2>
    <form (ngSubmit)="onSubmit()">
      <div>
        <label>Imie:</label>
        <input type="text" [(ngModel)]="employee.name" name="name" required>
      </div>
      <div>
        <label>Stanowisko:</label>
        <input type="text" [(ngModel)]="employee.position" name="position" required>
      </div>
      <div>
        <label>Pensja:</label>
        <input type="number" [(ngModel)]="employee.salary" name="salary">
      </div>>
      <button type="submit">Zapisz</button>
      <button type="button" (click)="cancel()">Cofnij</button>
    </form>
  `
})
export class EmployeeAddComponent implements OnInit {
  private route = inject(ActivatedRoute);
  private router = inject(Router);
  private dataService = inject(DataService);

  // Категория определяется параметром пути
  companyId: string = '';
  employee = { name: '', position: '' , salary: ''};

  ngOnInit() {
    // Получаем ID компании из URL (path parameter)
    this.companyId = this.route.snapshot.paramMap.get('id') || '';
  }

  onSubmit() {
    const payload = { ...this.employee, companyId: this.companyId };
    this.dataService.addEmployee(payload).subscribe({
      next: () => {
        this.router.navigate(['/companies', this.companyId]);
      },
      error: (err) => console.error('Błąd dodania pracownika:', err)
    });
  }

  cancel() {
    this.router.navigate(['/companies', this.companyId]);
  }
}
