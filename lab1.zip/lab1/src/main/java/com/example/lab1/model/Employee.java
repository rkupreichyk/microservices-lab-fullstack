package com.example.lab1.model;

import java.io.Serializable;
import java.util.Objects;

public class Employee implements Serializable, Comparable<Employee> {
    private static final long serialVersionUID = 1L;

    private String name;
    private String position;
    private double salary;
    private transient Company company;

    public static class Builder {
        private String name;
        private String position;
        private double salary;
        private Company company;

        public Builder name(String name) { this.name = name; return this; }
        public Builder position(String position) { this.position = position; return this; }
        public Builder salary(double salary) { this.salary = salary; return this; }
        public Builder company(Company company) { this.company = company; return this; }
        public Employee build() {
            Employee e = new Employee();
            e.name = this.name;
            e.position = this.position;
            e.salary = this.salary;
            e.company = this.company;
            return e;
        }
    }

    public String getName() { return name; }
    public String getPosition() { return position; }
    public double getSalary() { return salary; }
    public Company getCompany() { return company; }

    public void setCompany(Company company) { this.company = company; }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Employee)) return false;
        Employee e = (Employee) o;
        return Double.compare(e.salary, salary) == 0 && Objects.equals(name, e.name) && Objects.equals(position, e.position);
    }

    @Override
    public int hashCode() { return Objects.hash(name, position, salary); }

    @Override
    public int compareTo(Employee o) {
        int cmp = Double.compare(this.salary, o.salary);
        return cmp != 0 ? cmp : this.name.compareTo(o.name);
    }

    @Override
    public String toString() {
        String companyName = company == null ? "<no-company>" : company.getName();
        return String.format("Employee{name='%s', position='%s', salary=%.2f, company='%s'}", name, position, salary, companyName);
    }
}