package com.example.controller;

import com.example.collection.EmployeeCollectionDto;
import com.example.create.EmployeeCreateDto;
import com.example.read.EmployeeReadDto;
import com.example.service.EmployeeService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.net.URI;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

@RestController
@RequestMapping("/api/employees")
public class EmployeeController {
    private final EmployeeService employeeService;

    public EmployeeController(EmployeeService employeeService) {
        this.employeeService = employeeService;
    }

    // GET /api/employees  (all employees)
    @GetMapping
    public ResponseEntity<List<EmployeeCollectionDto>> getAll() {
        return ResponseEntity.ok(employeeService.findAll());
    }

    // GET /api/employees/{id}
    @GetMapping("/{id}")
    public ResponseEntity<EmployeeReadDto> getById(@PathVariable UUID id) {
        Optional<EmployeeReadDto> optionalEmployeeReadDto = employeeService.findById(id);
        if (optionalEmployeeReadDto.isPresent()) {
            return ResponseEntity.ok(optionalEmployeeReadDto.get());
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    // GET /api/employees/{companyId}  (elements from single category)
    @GetMapping("/by-company/{companyId}")
    public ResponseEntity<List<EmployeeCollectionDto>> getByCompany(@PathVariable UUID companyId) {
        Optional<List<EmployeeCollectionDto>> employeesByCompanyId = employeeService.findByCompanyId(companyId);
        if (employeesByCompanyId.isEmpty()) {
            return ResponseEntity.notFound().build(); // несуществующая категория -> 404
        }
        return ResponseEntity.ok(employeesByCompanyId.get()); // может быть пустой список -> 200
    }

    // POST /api/employees
    @PostMapping
    public ResponseEntity<EmployeeReadDto> create(@RequestBody EmployeeCreateDto dto) {
        Optional<EmployeeReadDto> employeeReadDto = employeeService.create(dto);
        if (employeeReadDto.isEmpty()){
            return ResponseEntity.badRequest().build(); // not existing company provided
        }
        URI location = URI.create("/api/employees/" + employeeReadDto.get().getId());
        return ResponseEntity.created(location).body(employeeReadDto.get());
    }

    // PUT /api/employees/{id}
    @PutMapping("/{id}")
    public ResponseEntity<EmployeeReadDto> update(@PathVariable UUID id, @RequestBody EmployeeCreateDto dto) {
        Optional<EmployeeReadDto> employeeReadDto = employeeService.update(id, dto);
        if (employeeReadDto.isEmpty()) {
            return ResponseEntity.badRequest().build();
        }

        return ResponseEntity.ok(employeeReadDto.get());
    }


    // DELETE /api/employees/{id}
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable UUID id) {
        employeeService.delete(id);
        return ResponseEntity.noContent().build();
    }
}
