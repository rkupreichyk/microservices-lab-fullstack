package com.example.controller;

import com.example.collection.CompanyCollectionDto;
import com.example.create.CompanyCreateDto;
import com.example.model.Company;
import com.example.read.CompanyReadDto;
import com.example.service.CompanyService;
import org.springframework.http.ResponseEntity;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.net.URI;
import java.util.List;
import java.util.Optional;
import java.util.UUID;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/companies")
public class CompanyController {
    private final CompanyService companyService;

    public CompanyController(CompanyService companyService) {
        this.companyService = companyService;
    }

    // GET /api/companies  (collection)
    @GetMapping
    public ResponseEntity<List<CompanyCollectionDto>> getAll() {
        List<CompanyCollectionDto> collectionDtos = companyService.findAll();
        return ResponseEntity.ok(collectionDtos);
    }

    // GET /api/companies/{id}
    @GetMapping("/{id}")
    public ResponseEntity<CompanyReadDto> getById(@PathVariable UUID id) {
        Optional<CompanyReadDto> companyOptional = companyService.findById(id);
        return convertToResponseEntity(companyOptional, ResponseEntity.notFound().build());
    }

    // POST /api/companies
    @PostMapping
    public ResponseEntity<CompanyReadDto> create(@RequestBody CompanyCreateDto dto) {
        CompanyReadDto saved = companyService.create(dto);
        URI location = URI.create("/api/companies/" + saved.getId());
        return ResponseEntity.created(location).body(saved);
    }

    // PUT /api/companies/{id}
    @PutMapping("/{id}")
    public ResponseEntity<CompanyReadDto> update(@PathVariable UUID id, @RequestBody CompanyCreateDto dto) {
        Optional<CompanyReadDto> companyOptional = companyService.update(id, dto);
        return convertToResponseEntity(companyOptional, ResponseEntity.badRequest().build());
    }

    // DELETE /api/companies/{id}
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable UUID id) {
        companyService.delete(id);
        return ResponseEntity.noContent().build();
    }


    private static ResponseEntity<CompanyReadDto> convertToResponseEntity(Optional<CompanyReadDto> companyOptional,
                                                                          ResponseEntity<CompanyReadDto> emptyResponse) {
        if (companyOptional.isPresent()) {
            return ResponseEntity.ok(companyOptional.get());
        } else {
            return emptyResponse;
        }
    }
}
