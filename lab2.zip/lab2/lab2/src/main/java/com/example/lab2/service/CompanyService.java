package com.example.lab2.service;

import com.example.lab2.model.Company;
import com.example.lab2.repository.CompanyRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.UUID;

@Service
public class CompanyService {
    private final CompanyRepository repository;

    public CompanyService(CompanyRepository repository) {
        this.repository = repository;
    }

    public List<Company> findAll() { return repository.findAll(); }
    public Company save(Company company) { return repository.save(company); }
    public void delete(UUID id) { repository.deleteById(id); }
}
