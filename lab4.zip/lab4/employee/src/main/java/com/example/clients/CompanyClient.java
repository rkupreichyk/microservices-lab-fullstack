package com.example.clients;

import com.example.read.CompanyReadDto;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestClient;

import java.util.Optional;
import java.util.UUID;

@Service
public class CompanyClient {
    private final RestClient restClient;

    @Autowired
    public CompanyClient(RestClient restClient) {
        this.restClient = restClient;
    }

    public Optional<CompanyReadDto> findById(UUID companyId){
        try{
            return Optional.of(
                    restClient
                            .get()
                            .uri("http://localhost:8081/api/companies/" + companyId.toString())
                            .retrieve()
                            .body(CompanyReadDto.class));
        } catch (Exception e){
            System.out.println("Exception when trying to get company by id " + companyId);
            return Optional.empty();
        }

    }

}
