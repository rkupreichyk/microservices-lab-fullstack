package com.example.lab2.service;

import com.example.lab2.model.Employee;
import com.example.lab2.model.Company;
import com.example.lab2.repository.EmployeeRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.UUID;

@Service
public class EmployeeService {
    private final EmployeeRepository repository;

    public EmployeeService(EmployeeRepository repository) {
        this.repository = repository;
    }

    public List<Employee> findAll() { return repository.findAll(); }
    public List<Employee> findByCompany(Company company) { return repository.findByCompany(company); }
    public Employee save(Employee employee) { return repository.save(employee); }
    public void delete(UUID id) { repository.deleteById(id); }
}
