import { Routes } from '@angular/router';
import { CompaniesComponent } from './features/company/pages/page.companies';
import { CompanyAddComponent } from './features/company/pages/company-add.component';
import { CompanyEditComponent } from './features/company/pages/company-edit.component';
import {CompanyDetailsComponent} from './features/company/pages/company-details.component';
import {EmployeeAddComponent} from './features/company/pages/employee-add.component';
import {EmployeeEditComponent} from './features/company/pages/employee-edit.component';
import {EmployeeDetailsComponent} from './features/company/pages/employee-details.component';

export const routes: Routes = [
  { path: 'companies', component: CompaniesComponent }, // Теперь по адресу /products откроется ваша страница
  { path: '', redirectTo: '/companies', pathMatch: 'full' }, // Перенаправление с главной на вашу страницу
  { path: 'companies/add', component: CompanyAddComponent },
  { path: 'companies/edit/:id', component: CompanyEditComponent },
  { path: 'companies/:id', component: CompanyDetailsComponent },
  { path: 'companies/:id/employees/add', component: EmployeeAddComponent },
  { path: 'companies/:companyId/employees/edit/:employeeId', component: EmployeeEditComponent },
  { path: 'companies/:companyId/employees/details/:employeeId', component: EmployeeDetailsComponent }
];
