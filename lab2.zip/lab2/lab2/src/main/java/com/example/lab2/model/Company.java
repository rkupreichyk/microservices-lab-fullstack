package com.example.lab2.model;

import jakarta.persistence.*;
import java.io.Serializable;
import java.util.*;

@Entity
@Table(name = "companies")
public class Company implements Serializable {

    @Id
    private UUID id = UUID.randomUUID();

    @Column(nullable = false)
    private String name;

    private String industry;

    @OneToMany(mappedBy = "company", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    private List<Employee> employees = new ArrayList<>();

    public Company() {}

    public Company(String name, String industry) {
        this.name = name;
        this.industry = industry;
    }

    public UUID getId() { return id; }
    public String getName() { return name; }
    public String getIndustry() { return industry; }
    public List<Employee> getEmployees() { return employees; }

    @Override
    public String toString() {
        return "Company{" + "id=" + id + ", name='" + name + '\'' + ", industry='" + industry + '\'' + '}';
    }
}
