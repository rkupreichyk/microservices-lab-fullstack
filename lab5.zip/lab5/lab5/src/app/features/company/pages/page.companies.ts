import {Component, OnInit, inject, ChangeDetectorRef} from '@angular/core';
import { CommonModule } from '@angular/common';
import { DataService } from './data.service';
import { Company } from './data.model';
import {RouterLink} from '@angular/router';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [CommonModule, RouterLink],
  templateUrl: './app.companies.html'
})
export class CompaniesComponent implements OnInit {
  private dataService = inject(DataService);
  private cdr = inject(ChangeDetectorRef);

  companies: Company[] = [];
  isLoading = true;

  ngOnInit() {
    this.dataService.getCompanies().subscribe({
      next: (data) => {
        this.companies = data;
        this.isLoading = false;
      },
      error: (err) => {
        console.error('Błąd zapytania do Gateway', err);
        this.isLoading = false;
      },
      complete: () => {
        this.isLoading = false;
        this.cdr.detectChanges();
      }
    });
  }

  protected onDelete(id: string) {
    this.dataService.deleteCompany(id).subscribe({
      next: () => {
        // Фильтруем массив: оставляем только те компании, ID которых не равен удаленному
        this.companies = this.companies.filter(c => c.id !== id);
        console.log(`Firma z ID ${id} zostala usunięta`);
      },
      error: (err) => {
        console.error('Błąd usunięcia:', err);
      }
    });
  }
}
