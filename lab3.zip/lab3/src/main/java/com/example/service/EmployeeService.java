package com.example.service;

import com.example.collection.EmployeeCollectionDto;
import com.example.create.EmployeeCreateDto;
import com.example.model.Employee;
import com.example.model.Company;
import com.example.read.CompanyReadDto;
import com.example.read.EmployeeReadDto;
import com.example.repository.EmployeeRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.UUID;
import java.util.stream.Collectors;

@Service
public class EmployeeService {
    private final EmployeeRepository repository;
    private final CompanyService companyService;

    public EmployeeService(EmployeeRepository repository, CompanyService companyService) {
        this.repository = repository;
        this.companyService = companyService;
    }

    public List<EmployeeCollectionDto> findAll() {
        List<EmployeeCollectionDto> list = repository.findAll().stream()
                .map(e -> new EmployeeCollectionDto(e.getId(), e.getName(), e.getPosition()))
                .collect(Collectors.toList());
        return list;
    }

    public Optional<EmployeeReadDto> findById(UUID id) {
        Optional<Employee> employeeOptional = repository.findById(id);
        if (employeeOptional.isPresent()) {
            Employee foundEmployee = employeeOptional.get();
            EmployeeReadDto employeeReadDto = EmployeeReadDto.from(foundEmployee);
            return Optional.of(employeeReadDto);
        } else {
            return Optional.empty();
        }
    }

    public Optional<List<EmployeeCollectionDto>> findByCompanyId(UUID companyId) {
        Optional<CompanyReadDto> companyReadDto = companyService.findById(companyId);
        if (!companyService.existsById(companyId)) {
            return Optional.empty();
        }
        CompanyReadDto foundExistingCompany = companyReadDto.get();
        Company company = new Company(foundExistingCompany.getName(), foundExistingCompany.getIndustry());
        company.setId(foundExistingCompany.getId());
        List<EmployeeCollectionDto> list = repository.findByCompany(company).stream()
                .map(e -> new EmployeeCollectionDto(e.getId(), e.getName(), e.getPosition()))
                .collect(Collectors.toList());
        return Optional.of(list);
    }

    public List<Employee> findByCompany(Company company) {
        return repository.findByCompany(company);
    }

    public Optional<EmployeeReadDto> create(EmployeeCreateDto employeeCreateDto) {
        if (employeeCreateDto.getCompanyId() == null) {
            return Optional.empty();
        }
        Optional<CompanyReadDto> companyReadDto = companyService.findById(employeeCreateDto.getCompanyId());
        // компания должна существовать
        if (companyReadDto.isEmpty()) {
            return Optional.empty();
        }
        Company company = new Company(companyReadDto.get().getName(), companyReadDto.get().getIndustry());
        company.setId(companyReadDto.get().getId());
        Employee employeeToSave = new Employee(employeeCreateDto.getName(), employeeCreateDto.getPosition(), employeeCreateDto.getSalary(), company);
        Employee saved = repository.save(employeeToSave);
        return Optional.of(EmployeeReadDto.from(saved));
    }

    public Optional<EmployeeReadDto> update(UUID id, EmployeeCreateDto employeeCreateDto) {
        if (employeeCreateDto.getCompanyId() == null) {
            return Optional.empty();
        }
        Optional<Employee> existingEmployeeOptional = repository.findById(id);
        if (existingEmployeeOptional.isEmpty()) {
            return Optional.empty();
        }
        Optional<CompanyReadDto> companyReadDto = companyService.findById(employeeCreateDto.getCompanyId());
        // компания должна существовать
        if (!companyService.existsById(employeeCreateDto.getCompanyId())) {
            return Optional.empty();
        }
        Company company = new Company(companyReadDto.get().getName(), companyReadDto.get().getIndustry());
        company.setId(companyReadDto.get().getId());
        Employee employeeToSave = new Employee(employeeCreateDto.getName(), employeeCreateDto.getPosition(), employeeCreateDto.getSalary(), company);
        employeeToSave.setId(existingEmployeeOptional.get().getId());
        Employee saved = repository.save(employeeToSave);
        return Optional.of(EmployeeReadDto.from(saved));
    }

    public void delete(UUID id) {
        if (repository.existsById(id)) {
            repository.deleteById(id);
        }
    }
}
