import { Component, OnInit, inject, ChangeDetectorRef } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ActivatedRoute, RouterLink } from '@angular/router';
import { DataService } from './data.service';
import { Employee } from './data.model';

@Component({
  standalone: true,
  imports: [CommonModule, RouterLink],
  template: `
    <div *ngIf="employee">
      <h2>Szczególy pracownika</h2>
      <p><strong>Imie:</strong> {{ employee.name }}</p>
      <p><strong>Stanowisko:</strong> {{ employee.position }}</p>
      <p><strong>Pensja:</strong> {{ employee.salary | currency }}</p>
      <p><strong>ID procownika:</strong> {{ employee.id }}</p>
      <p><strong>ID firmy:</strong> {{ companyId }}</p>

      <hr>
      <div class="actions">
        <button [routerLink]="['/companies', companyId]">Wróć</button>

        <button [routerLink]="['/companies', companyId, 'employees', 'edit', employeeId]">
          Edytuj
        </button>
      </div>
    </div>
  `
})
export class EmployeeDetailsComponent implements OnInit {
  private route = inject(ActivatedRoute);
  private dataService = inject(DataService);
  private cdr = inject(ChangeDetectorRef);

  companyId: string = '';
  employeeId: string = '';
  employee: Employee | null = null;

  ngOnInit() {
    // Категория и элемент определяются параметрами пути
    this.companyId = this.route.snapshot.paramMap.get('companyId') || '';
    this.employeeId = this.route.snapshot.paramMap.get('employeeId') || '';

    if (this.employeeId) {
      this.dataService.getEmployeeById(this.employeeId).subscribe({
        next: (data) => {
          this.employee = data;
          this.cdr.detectChanges();
        },
        error: (err) => console.error('bład pobrania szczegól pracownika:', err)
      });
    }
  }
}
