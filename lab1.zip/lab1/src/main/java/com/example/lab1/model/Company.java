package com.example.lab1.model;

import java.io.Serializable;
import java.util.*;

public class Company implements Serializable, Comparable<Company> {
    private static final long serialVersionUID = 1L;

    private String name;
    private String industry;
    private List<Employee> employees = new ArrayList<>();

    public static class Builder {
        private String name;
        private String industry;

        public Builder name(String name) { this.name = name; return this; }
        public Builder industry(String industry) { this.industry = industry; return this; }
        public Company build() {
            Company c = new Company();
            c.name = this.name;
            c.industry = this.industry;
            return c;
        }
    }

    public String getName() { return name; }
    public String getIndustry() { return industry; }
    public List<Employee> getEmployees() { return employees; }

    @Override
    public int compareTo(Company o) { return this.name.compareTo(o.name); }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Company)) return false;
        Company company = (Company) o;
        return Objects.equals(name, company.name) && Objects.equals(industry, company.industry);
    }

    @Override
    public int hashCode() { return Objects.hash(name, industry); }

    @Override
    public String toString() {
        return String.format("Company{name='%s', industry='%s', employees=%d}", name, industry, employees.size());
    }
}