package com.example.lab2.init;

import com.example.lab2.model.Company;
import com.example.lab2.model.Employee;
import com.example.lab2.service.CompanyService;
import com.example.lab2.service.EmployeeService;
import org.springframework.stereotype.Component;
import jakarta.annotation.PostConstruct;

@Component
public class DataInitializer {

    private final CompanyService companyService;
    private final EmployeeService employeeService;

    public DataInitializer(CompanyService companyService, EmployeeService employeeService) {
        this.companyService = companyService;
        this.employeeService = employeeService;
    }

    @PostConstruct
    public void init() {
        Company tech = new Company("TechCorp", "IT");
        Company finance = new Company("FinancePlus", "Finanse");

        companyService.save(tech);
        companyService.save(finance);

        employeeService.save(new Employee("Raman Kupreichyk", "Programista", 80000, tech));
        employeeService.save(new Employee("pracownik2", "Tester", 55000, tech));
        employeeService.save(new Employee("pracownik3", "Analityk", 70000, finance));
        employeeService.save(new Employee("pracownik4", "Księgowy", 60000, finance));

        System.out.println("Dane testowe zostały zapisane w bazie!");
    }
}
