import { Component, OnInit, inject } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { DataService } from './data.service';
import {CommonModule} from '@angular/common';
import {FormsModule} from '@angular/forms';

@Component({
  standalone: true,
  imports: [CommonModule, FormsModule],
  template: `
    <h2>Edycja pracownika</h2>
    <form (ngSubmit)="onSubmit()">
      <div>
        <label>Imie:</label>
        <input type="text" [(ngModel)]="employee.name" name="name" required>
      </div>
      <div>
        <label>Stanowisko:</label>
        <input type="text" [(ngModel)]="employee.position" name="position" required>
      </div>
      <div>
        <label>Pensja:</label>
        <input type="number" [(ngModel)]="employee.salary" name="salary" required>
      </div>
      <button type="submit">Zapisz</button>
      <button type="button" (click)="cancel()">Cofnij</button>
    </form>
  `
})
export class EmployeeEditComponent implements OnInit {
  private route = inject(ActivatedRoute);
  private router = inject(Router);
  private dataService = inject(DataService);

  companyId: string = '';
  employeeId: string = '';
  employee = { name: '', position: '', salary: 0 };

  ngOnInit() {
    // Получаем оба параметра из пути (Задание 6)
    this.companyId = this.route.snapshot.paramMap.get('companyId') || '';
    this.employeeId = this.route.snapshot.paramMap.get('employeeId') || '';

    if (this.employeeId) {
      // Заполняем форму оригинальными значениями (Задание 6)
      this.dataService.getEmployeeById(this.employeeId).subscribe(data => {
        this.employee = {
          name: data.name,
          position: data.position,
          salary: data.salary
        };
      });
    }
  }

  onSubmit() {
    const payload = {
      name: this.employee.name,
      position: this.employee.position,
      // Принудительно преобразуем в число
      salary: Number(this.employee.salary),
      // Добавляем ID компании, если сервер его требует
      companyId: this.companyId
    };

    this.dataService.updateEmployee(this.employeeId, payload).subscribe({
      next: () => this.router.navigate(['/companies', this.companyId]),
      error: (err) => {
        console.error('Bład 400!:', err);
      }
    });
  }

  cancel() {
    this.router.navigate(['/companies', this.companyId]);
  }
}
