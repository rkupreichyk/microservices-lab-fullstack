import { Component, OnInit, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { DataService } from './data.service';

@Component({
  standalone: true,
  imports: [CommonModule, FormsModule],
  template: `
    <h2>Edycja firmy</h2>
    <form (ngSubmit)="onSubmit()">
      <div>
        <label>Nazwa:</label>
        <input type="text" [(ngModel)]="company.name" name="name" required>
      </div>
      <div>
        <label>Branża:</label>
        <input type="text" [(ngModel)]="company.industry" name="industry" required>
      </div>
      <button type="submit">Zatwierdz</button>
      <button type="button" (click)="cancel()">Cofnij</button>
    </form>
  `
})
export class CompanyEditComponent implements OnInit {
  private route = inject(ActivatedRoute);
  private router = inject(Router);
  private dataService = inject(DataService);

  id: string = '';
  company = { name: '', industry: '' };

  ngOnInit() {
    const idParam = this.route.snapshot.paramMap.get('id');
    if (idParam) {
      this.id = idParam;
      this.dataService.getCompanyById(this.id).subscribe(data => {
        this.company = { name: data.name, industry: data.industry };
      });
    }
  }

  onSubmit() {
    this.dataService.updateCompany(this.id, this.company).subscribe({
      next: () => this.router.navigate(['/companies']),
      error: (err) => console.error('Błąd przy odnowieniu:', err)
    });
  }

  cancel() {
    this.router.navigate(['/companies']);
  }
}
