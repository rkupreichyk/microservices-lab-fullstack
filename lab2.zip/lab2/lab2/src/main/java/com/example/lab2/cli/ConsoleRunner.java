package com.example.lab2.cli;

import com.example.lab2.model.*;
import com.example.lab2.service.*;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Scanner;
import java.util.UUID;

@Component
public class ConsoleRunner implements CommandLineRunner {

    private final CompanyService companyService;
    private final EmployeeService employeeService;

    public ConsoleRunner(CompanyService companyService, EmployeeService employeeService) {
        this.companyService = companyService;
        this.employeeService = employeeService;
    }

    @Override
    public void run(String... args) {
        Scanner scanner = new Scanner(System.in);
        String command;

        System.out.println("=== SPRING DATA CLI ===");
        help();

        while (true) {
            System.out.print("\n> ");
            command = scanner.nextLine();

            switch (command) {
                case "companies" -> companyService.findAll().forEach(System.out::println);
                case "employees" -> employeeService.findAll().forEach(System.out::println);
                case "add" -> addEmployee(scanner);
                case "delete" -> deleteEmployee(scanner);
                case "help" -> help();
                case "exit" -> {
                    return;
                }
                default -> System.out.println("wpisz 'help'.");
            }
        }
    }

    private void addEmployee(Scanner scanner) {
        System.out.print("Imie: ");
        String name = scanner.nextLine();
        System.out.print("Stanowisko: ");
        String position = scanner.nextLine();
        System.out.print("Wynagrodzenie: ");
        double salary = Double.max(0,Double.parseDouble(scanner.nextLine()));



        System.out.println("Wybierz firmę:");
        List<Company> companies = companyService.findAll();
        for (int i = 0; i < companies.size(); i++) {
            System.out.println((i + 1) + ". " + companies.get(i).getName());
        }
        int choice = Integer.parseInt(scanner.nextLine());
        Company company = companies.get(choice - 1);

        employeeService.save(new Employee(name, position, salary, company));
        System.out.println("Pracownik dodany");
    }

    private void deleteEmployee(Scanner scanner) {
        System.out.print("Wprowadź id pracownika:");
        String id = scanner.nextLine();
        employeeService.delete(UUID.fromString(id));
        System.out.println("Pracownik usunięty");
    }

    private void help() {
        System.out.println("""
                Dostępne polecenia:
                companies-Pokaż wszystkie firmy
                employees-Pokaż wszystkich pracowników
                add-Dodaj pracownika
                delete-Usuń pracownika
                help-Pokaż polecenia
                exit-wyjdź
                """);
    }
}
