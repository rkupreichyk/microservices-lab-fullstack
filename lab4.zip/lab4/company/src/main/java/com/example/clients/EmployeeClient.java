package com.example.clients;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestClient;

import java.util.Optional;
import java.util.UUID;

@Service
public class EmployeeClient {
    private final RestClient restClient;

    @Autowired
    public EmployeeClient(RestClient restClient) {
        this.restClient = restClient;
    }

    public int getEmployeeCount(UUID companyId) {
        try {
            return restClient
                    .get()
                    .uri("http://localhost:8080/api/employees/count/" + companyId.toString())
                    .retrieve()
                    .body(Integer.class);
        } catch (Exception e) {
            System.err.println("Ошибка при вызове Employee Service: " + e.getMessage());
            e.printStackTrace(); // Это покажет полную причину (404, Connection Refused и т.д.)
            return 0;
        }
    }

    public void deleteEmployeesByCompanyId(UUID companyId) {
        try {
            restClient
                    .delete()
                    .uri("http://localhost:8080/api/employees/by-company/" + companyId.toString())
                    .retrieve()
                    .toBodilessEntity();
        } catch (Exception e) {
            System.err.println("can not delete employees by company id " + companyId);
        }
    }
}
