package com.example.model;

import com.example.model.Company;
import jakarta.persistence.*;

import java.io.Serializable;
import java.util.UUID;

//@Entity
//@Table(name = "employees")
public class Employee implements Serializable {

    @Id
    private UUID id = UUID.randomUUID();

    @Column(nullable = false)
    private String name;

    private String position;
    private double salary;

    private UUID companyId;

    public Employee() {}

    public Employee(String name, String position, double salary, UUID companyId) {
        this.name = name;
        this.position = position;
        this.salary = salary;
        this.companyId = companyId;
    }

    public UUID getId() { return id; }
    public String getName() { return name; }
    public String getPosition() { return position; }
    public double getSalary() { return salary; }
    public UUID getCompanyId() { return companyId; }

    @Override
    public String toString() {
        return "Employee{" + "id=" + id + ", name='" + name + '\'' + ", position='" + position + '\'' + ", salary=" + salary + '}';
    }

    public void setId(UUID id) {
        this.id = id;
    }
    public void setName(String name) {
        this.name = name;
    }

    public void setPosition(String position) {
        this.position = position;
    }

    public void setSalary(double salary) {
        this.salary = salary;
    }

    public void setCompany(UUID companyId) {
        this.companyId = companyId;
    }

}
