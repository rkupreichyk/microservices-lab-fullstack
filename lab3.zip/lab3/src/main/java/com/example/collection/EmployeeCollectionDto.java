package com.example.collection;

import java.io.Serializable;
import java.util.UUID;

public class EmployeeCollectionDto implements Serializable {
    private UUID id;
    private String name;
    private String position;

    public EmployeeCollectionDto() {}

    public EmployeeCollectionDto(UUID id, String name, String position) {
        this.id = id;
        this.name = name;
        this.position = position;
    }

    public UUID getId() { return id; }
    public String getName() { return name; }
    public String getPosition() { return position; }
}
