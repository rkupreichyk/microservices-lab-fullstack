package com.example.lab1.model;

import java.io.Serializable;

public class EmployeeDto implements Serializable, Comparable<EmployeeDto> {
    private static final long serialVersionUID = 1L;

    private String name;
    private String position;
    private double salary;
    private String companyName;

    public EmployeeDto() {}

    public EmployeeDto(String name, String position, double salary, String companyName) {
        this.name = name;
        this.position = position;
        this.salary = salary;
        this.companyName = companyName;
    }

    public static EmployeeDto from(Employee e) {
        String company = e.getCompany() == null ? "<no-company>" : e.getCompany().getName();
        return new EmployeeDto(e.getName(), e.getPosition(), e.getSalary(), company);
    }

    @Override
    public int compareTo(EmployeeDto o) {
        int cmp = Double.compare(this.salary, o.salary);
        return cmp != 0 ? cmp : this.name.compareTo(o.name);
    }

    @Override
    public String toString() {
        return String.format("EmployeeDto{name='%s', position='%s', salary=%.2f, company='%s'}", name, position, salary, companyName);
    }
}
