package com.example.service;

import com.example.clients.EmployeeClient;
import com.example.collection.CompanyCollectionDto;
import com.example.create.CompanyCreateDto;
import com.example.model.Company;
import com.example.read.CompanyReadDto;
import com.example.repository.CompanyRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.UUID;
import java.util.stream.Collectors;

@Service
public class CompanyService {
    private final CompanyRepository repository;
    private final EmployeeClient employeeClient;

    public CompanyService(CompanyRepository repository, EmployeeClient employeeClient) {
        this.repository = repository;
        this.employeeClient = employeeClient;
    }

    public List<CompanyCollectionDto> findAll() {
        return repository.findAll().stream()
                .map(c -> new CompanyCollectionDto(c.getId(), c.getName()))
                .collect(Collectors.toList());
    }

    /*public Optional<CompanyReadDto> findById(UUID id) {
        Optional<Company> companyOptional = repository.findById(id);
        if (companyOptional.isPresent()) {
            Company company = companyOptional.get();
            CompanyReadDto companyReadDto = CompanyReadDto.from(company);
            return Optional.of(companyReadDto);
        } else {
            return Optional.empty();
        }
    }*/

    public Optional<CompanyReadDto> findById(UUID id) {
        return repository.findById(id).map(company -> {
            // 1. Получаем живые данные о количестве сотрудников из другого сервиса
            int actualCount = employeeClient.getEmployeeCount(id);

            // 2. Создаем DTO вручную, подставляя актуальное число
            return new CompanyReadDto(
                    company.getId(),
                    company.getName(),
                    company.getIndustry(),
                    actualCount // передаем полученное извне число вместо 0
            );
        });
    }

    public CompanyReadDto create(CompanyCreateDto companyCreateDto) {
        Company companyToCreate = new Company( companyCreateDto.getName(), companyCreateDto.getIndustry());
        Company saved = repository.save(companyToCreate);
        return CompanyReadDto.from(saved);
    }

    public Optional<CompanyReadDto> update(UUID id, CompanyCreateDto companyCreateDto) {
        Optional<Company> companyOptional = repository.findById(id);
        if (companyOptional.isPresent()) {
            Company company = companyOptional.get();
            company.setName(companyCreateDto.getName());
            company.setIndustry(companyCreateDto.getIndustry());
            Company updatedCompany = repository.save(company);
            CompanyReadDto companyReadDto = CompanyReadDto.from(updatedCompany);
            return Optional.of(companyReadDto);
        }
        else  {
            return Optional.empty();
        }
    }



    public void delete(UUID id) {
        if (repository.existsById(id)) {
            employeeClient.deleteEmployeesByCompanyId(id);

            repository.deleteById(id);
        }
    }

}
