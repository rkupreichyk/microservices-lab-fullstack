export interface Company {
  id: string;
  name: string;
  industry: string;
  employeeCount: number;
}

export interface Employee {
  id:string;
  companyId: string;
  name: string;
  position: string;
  salary: number;
}
