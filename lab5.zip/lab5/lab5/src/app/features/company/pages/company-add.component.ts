import { Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { DataService } from './data.service';

@Component({
  selector: 'app-company-add',
  standalone: true,
  imports: [CommonModule, FormsModule],
  template: `
    <h2>Dodać nową firmę</h2>
    <form (ngSubmit)="onSubmit()">
      <div>
        <label>Nazwa:</label>
        <input type="text" [(ngModel)]="newCompany.name" name="name" required>
      </div>
      <div>
        <label>Branża:</label>
        <input type="text" [(ngModel)]="newCompany.industry" name="industry" required>
      </div>
      <button type="submit">Zapisz</button>
      <button type="button" (click)="goBack()">Cofnij</button>
    </form>
  `
})
export class CompanyAddComponent {
  private dataService = inject(DataService);
  private router = inject(Router);

  newCompany = { name: '', industry: '' };

  onSubmit() {
    this.dataService.addCompany(this.newCompany).subscribe({
      next: () => {
        this.router.navigate(['/companies']);
      },
      error: (err) => console.error('Błąd dodania:', err)
    });
  }

  goBack() {
    this.router.navigate(['/companies']);
  }
}
